//utilitzar jquery ui de menu "Default functionality"
$( function() {
    $( "#menu" ).menu();
  } );

  //posem les imatges al div #contenido
  $("#contenido").load(link,"#contenido");